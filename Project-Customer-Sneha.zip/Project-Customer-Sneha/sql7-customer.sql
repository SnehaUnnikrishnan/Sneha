CREATE DATABASE  IF NOT EXISTS `customer_db`;
use `customer_db`;
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` int(3) not null AUTO_INCREMENT ,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `dob` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phn` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
  
delete from customer;
INSERT INTO `customer` VALUES 
	(1,'David','Adams','1997-01-11','male','david@gmail.com','993977801'),
	(2,'John','Doe','1999-02-12','male','john@gmail.com','888999737'),
	(3,'Ajay','Rao','1998-04-22','male','ajay@gmail.com','777567810'),
	(4,'Mary','Smith','1997-05-12','female','mary@gmail.com','887912782'),
	(5,'Maxwell','Dixon','1998-09-21','male','max@gmail.com','989288102');
commit;
    select * from `customer`;
    
    
    
    
     CREATE TABLE `login` (
 `id` int(3) not null,
  `uname` varchar(45) not null ,
  `pass` varchar(45) DEFAULT NULL,
`email` varchar(45) default null,
  PRIMARY KEY (`id`)
  );
  

INSERT INTO `login` VALUES 
	(1,'david','david','david@gmail.com'),
(2,'john','john','john@gmail.com'), 
(3,'ajay','ajay','ajay@gmail.com'),
(4,'mary','mary','mary@gmail.com'),  
(5,'maxwell','maxwell','maxwell@gmail.com');
commit;
    select * from `login`;
    